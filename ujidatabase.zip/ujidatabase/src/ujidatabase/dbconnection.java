package ujidatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class dbconnection {
    public static Connection con;
    public static Statement stm;
    
    public static boolean MySQLConnection() {
	String dbURL    = "jdbc:mysql://localhost:3306/";
	String username = "root";
	String password = "";
        String database = "lomba_ai";
        boolean connected = false;
	try {
            con = DriverManager.getConnection(dbURL + database, username, password);
            stm = con.createStatement();
            if (con != null) {
                JOptionPane.showMessageDialog(null, "Koneksi ke MySQL berhasil");
                connected = true;
            }
	} catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Koneksi ke MySQL gagal " + ex.getMessage());
	}
        return connected;
    }
    
}
