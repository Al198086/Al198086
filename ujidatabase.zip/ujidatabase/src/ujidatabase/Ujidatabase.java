
package ujidatabase;

public class Ujidatabase {
    
    public static void main(String[] args) {
        //tabelTotalKasus TotalKasus = new tabelTotalKasus();
        
        tabelTotalKasus.main(args);
    }
    
}
