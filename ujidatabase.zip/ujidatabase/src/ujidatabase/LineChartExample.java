package ujidatabase;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;  
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;  
import javax.swing.WindowConstants;
  
import org.jfree.chart.ChartFactory;  
import org.jfree.chart.ChartPanel;  
import org.jfree.chart.JFreeChart;  
import org.jfree.data.category.DefaultCategoryDataset;  

public class LineChartExample extends JFrame {
    private static final long serialVersionUID = 1L;  
    private dbconnection db = new dbconnection();
    private ResultSet rset;

    public LineChartExample(String title) {  
        super(title);  
        // Create dataset  
        DefaultCategoryDataset dataset = createDataset();  
        // Create chart  
        JFreeChart chart = ChartFactory.createLineChart(  
            "Total Kasus Covid-19",    // Chart title  
            "Hari Ke",                 // X-Axis Label  
            "Total Kasus",             // Y-Axis Label  
            dataset  
            );  

        ChartPanel panel = new ChartPanel(chart);  
        setContentPane(panel);  
    } 
    
    private DefaultCategoryDataset createDataset() {  
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();  

    //    if (dbconnection.MySQLConnection() == true) {
            String series[] = {"Aceh", "Bali", "Banten", "Babel", "Bengkulu", "DIY"};  

            try {
                String query = "SELECT * FROM v_kasus_total";
                rset = dbconnection.stm.executeQuery(query);
                while (rset.next()) {
                    for (int i=0; i< series.length; i++) {
                        //    dataset.addValue(245, series1, "2016-12-25");  
                        //    dataset.addValue(150, series2, "2016-12-19");
                        dataset.addValue(rset.getInt(series[i]), series[i], rset.getString("hari_ke"));  
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Data gagal ditampilkan" + ex.getMessage());
            }
    //    }
        return dataset;  
    }  
  
    public static void main(String[] args) {  
        SwingUtilities.invokeLater(() -> {  
            LineChartExample example = new LineChartExample("Line Chart");  
            example.setAlwaysOnTop(true);  
            example.pack();  
            example.setSize(600, 400);  
            example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);  
            example.setVisible(true);  
        });  
    }  
}
